  ________                          .__                    _____                 
 /  _____/______  ____  __ ________ |__| ____    ____     /  _  \ ______ ______  
/   \  __\_  __ \/  _ \|  |  \____ \|  |/    \  / ___\   /  /_\  \\____ \\____ \ 
\    \_\  \  | \(  <_> )  |  /  |_> >  |   |  \/ /_/  > /    |    \  |_> >  |_> >
 \______  /__|   \____/|____/|   __/|__|___|  /\___  /  \____|__  /   __/|   __/ 
        \/                   |__|           \//_____/           \/|__|   |__|    Unity: 1.0

				by Jason Jackson
This app is a "port" of the original WPF-based "Sorting App"
The functionality is all pretty much the same, with the added benefit of being 
available on Windows, MacOS, and Linux.

How to use:

Access either your saved classes or the app settings via the main menu. Be sure to check out availible settings.
Once on the classes page, hit the button to create a new class.
Before you can group the class, it must be populated by students. Press the edit button next to the class name.
Students can be added manually via the "Add" button, or by using an existing list (recommended).

As soon as you have a list of students copied, press the "Paste" button to automatically add your students.
The copied list must be formated with a return between each name -like so:

Todd Howard
Billy Billington
Stitcher Jim

After you populate your class (feel free to rename it via the input field at the top left),
return to the class list and adjust the grouping settings on the bottom. When these are to your liking,
hit the "Group" button to the right of the class name. This will take you to the group window, which will 
display your randomized groups in little subwindows. 

The size of these can be adjusted with the [-][+] buttons.They can also be moved by dragging from the top bar of each window.
Individual students can be moved or swapped around as well. When dragging a student to a blank part of another group window,
the student will be moved to that group. When dragging a student on top of another student, these students will swap groups.

There is currently no saving of randomized groups, but taking a screenshot is a decent workaround.

If you have any futher questions, feel free to 
contact me at jason.q.jackson@gmail.com

Happy Grouping!